
// functions that iframes are resized correctly
function getDocHeight(doc) {
  var docHt = 0, desh, bsh, sh, oh;
  if (doc.height) {
    docHt = doc.height;
  } else  {
	  if (doc.body.scrollHeight) {
		docHt = doc.body.scrollHeight;
	  } else if (doc.documentElement.scrollHeight) {
		docHt = doc.documentElement.scrollHeight;
	  } else if (doc.body.offsetHeight) {
		docHt = doc.body.offsetHeight;
	  }
  }
  return docHt;
}

function setIframeHeight(iframeName) {
  var iframeWin = window.frames[iframeName];
  var iframeEl = document.getElementById ? document.getElementById(iframeName): document.all ? document.all[iframeName] : null;
  if ( iframeEl && iframeWin ) {
    // helps resize (for some) if new doc shorter than previous
    iframeEl.style.height = "auto";
    iframeWin.document.body.style.backgroundColor = "#F2F2F2";    
    var docHt = getDocHeight(iframeWin.document);
    // need to add to height to be sure it will all show
    if (docHt) iframeEl.style.height = docHt + 30 + "px";
  }
}  