package samples.seminar.tsp;

import java.util.ArrayList;
import java.util.Random;


public class Generator {

    protected Random rand;

    protected int n;

    protected int maxDist;
    protected int[][] dist;

    protected int[] hamPath;

    public Generator(Random rand, int n, int maxDist) {
        this.rand = rand;
        this.n = n;
        this.maxDist= maxDist;
        this.dist = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                this.dist[i][j] = -1;
            }
        }
        this.hamPath = new int[n];
        generateHamCycle();
    }

    public int[][] generateMatrix() {  // matrix with splitted depot node
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                dist[i][j] = rand.nextInt(maxDist);
            }
        }
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (i == j || (i == n - 1 && j == 0) ) {
                    dist[i][j] = 0;
                } else {
                    if (hamPath[i] == j) dist[i][j] = 1;
                }
                //System.out.println("dist["+i+"]["+j+"] = "+dist[i][j]);
            }
        }
        return dist;
    }

    private void generateHamCycle() {
        for (int i = 0; i < n; i++) hamPath[i] = -1;
        ArrayList<Integer> dispo = new ArrayList<Integer>(n-2);
        for (int i = 1; i < n-1; i++) dispo.add(i);
        //System.out.println(dispo.toString());
        int next = 0;
        while(!dispo.isEmpty()) {
            hamPath[next] = dispo.remove(rand.nextInt(dispo.size()));
            next = hamPath[next];
        }
        for (int i = 1; i < n-1; i++) {
            if (hamPath[i] == -1) hamPath[i] = n-1;
        }
        hamPath[n-1] = 0;
        System.out.println(showHamPath());
    }

    public String showHamPath() {
        String s = ""+hamPath[0];
        int i = 1;
        while(i < hamPath.length) {
            s += " "+hamPath[i];
            i++;
        }
        return s;
    }

}
