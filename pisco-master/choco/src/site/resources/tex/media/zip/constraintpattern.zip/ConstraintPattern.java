package src.samples.seminar;

import src.choco.solver.ContradictionException;
import src.choco.solver.constraints.SConstraint;
import src.choco.solver.constraints.integer.AbstractLargeIntSConstraint;
import src.choco.solver.variables.integer.IntDomainVar;
import src.choco.util.IntIterator;

/**
 * Created by IntelliJ IDEA.
 * User: charles
 * Date: 29 mai 2008
 * Time: 18:22:00
 * To change this template use File | Settings | File Templates.
 */
public class ConstraintPattern extends AbstractLargeIntSConstraint {

    public ConstraintPattern(IntDomainVar[] vars) {
        super(vars);
    }


    /**
     * pretty printing of the object. This String is not constant and may depend on the context.
     *
     * @return a readable string representation of the object
     */
    public String pretty() {
        return null;
    }


    /**
     * check wether the tuple satisfy the constraint
     * @param tuple value
     * @return true if satisfy
     */
    public boolean isSatisfied(int[] tuple) {
        return false;
    }


    /**
     * Testing if all variables involved in the constraint are instantiated.
     *
     * @return wehter all the variables are completly instantiated
     */

    public boolean isCompletelyInstantiated() {
        return false;  
    }


    /**
     * Check wether it is equivalent to <i>compareTo</i> constraint.
     * @param compareTo a contraint
     * @return wether it is equivalent to <i>compareTo</i>
     */
    public final boolean isEquivalentTo(SConstraint compareTo) {
        return false;
    }


    /**
     * <i>Propagation:</i>
     * Propagating the constraint until local consistency is reached.
     *
     * @throws src.choco.solver.ContradictionException
     *          contradiction exception
     */

    public void propagate() throws ContradictionException {
        //Change if necessary
        constAwake(false);
    }

    
    /**
     * <i>Propagation:</i>
     * Propagating the constraint for the very first time until local
     * consistency is reached.
     *
     * @throws src.choco.solver.ContradictionException
     *          contradiction exception
     */

    public void awake() throws ContradictionException {
        //Change if necessary
        constAwake(false);
    }


    /**
     * Default propagation on instantiation: full constraint re-propagation.
     * @param varIdx index of the variable to reduce
     * @throws ContradictionException contradiction exception
     */
    public void awakeOnInst(int varIdx) throws ContradictionException {
        //Change if necessary
        constAwake(false);
    }


    /**
     * Default propagation on improved lower bound: propagation on domain revision.
     * @param varIdx index of the variable to reduce
     * @throws ContradictionException contradiction exception
     */

    public void awakeOnInf(int varIdx) throws ContradictionException {
        //Change if necessary
        constAwake(false);
    }


    /**
     * Default propagation on improved upper bound: propagation on domain revision.
     * @param varIdx index of the variable to reduce
     * @throws ContradictionException contradiction exception
     */
    public void awakeOnSup(int varIdx) throws ContradictionException {
        //Change if necessary
        constAwake(false);
    }


    /**
     * Default propagation on one value removal: propagation on domain revision.
     * @param varIdx index of the variable to reduce
     * @throws ContradictionException contradiction exception
     */
    public void awakeOnBounds(int varIdx) throws ContradictionException {
         //Change if necessary
        constAwake(false);
    }


    /**
     * Default propagation on one value removal: propagation on domain revision.
     * @param varIdx index of the variable to reduce
     * @throws ContradictionException contradiction exception
     */

    public void awakeOnRem(int varIdx, int val) throws ContradictionException {
        //Change if necessary
        constAwake(false);
    }

    /**
     * Default propagation on one value removal: propagation on domain revision.
     * @param varIdx index of the variable to reduce
     * @param deltaDomain iterator over remove values.
     * @throws ContradictionException contradiction exception
     */
    public void awakeOnRemovals(int varIdx, IntIterator deltaDomain) throws ContradictionException {
        //Change if necessary
        constAwake(false);
    }

    /**
     * <i>Propagation:</i>
     * Propagating the constraint when the domain of a variable has been
     * modified (shrunk) since the last consistent state.
     * @param idx index of the variable to reduce
     * @throws ContradictionException contradiction exception
     */

    public void awakeOnVar(int idx) throws ContradictionException {
        //Change if necessary
        constAwake(false);
    }


}
