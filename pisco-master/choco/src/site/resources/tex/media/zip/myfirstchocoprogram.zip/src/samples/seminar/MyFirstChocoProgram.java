package samples.seminar;/* ************************************************
 *           _       _                            *
 *          |  °(..)  |                           *
 *          |_  J||L _|        CHOCO solver       *
 *                                                *
 *     Choco is a java library for constraint     *
 *     satisfaction problems (CSP), constraint    *
 *     programming (CP) and explanation-based     *
 *     constraint solving (e-CP). It is built     *
 *     on a event-based propagation mechanism     *
 *     with backtrackable structures.             *
 *                                                *
 *     Choco is an open-source software,          *
 *     distributed under a BSD licence            *
 *     and hosted by sourceforge.net              *
 *                                                *
 *     + website : http://choco.emn.fr            *
 *     + support : choco@emn.fr                   *
 *                                                *
 *     Copyright (C) F. Laburthe,                 *
 *                   N. Jussien    1999-2008      *
 **************************************************
 *
 * Created by IntelliJ IDEA.
 * User: charles
 * Date: 13 nov. 2008
 * Since : Choco 2.0.1
 * 
 */

import choco.Choco;
import choco.cp.model.CPModel;
import choco.cp.solver.CPSolver;
import choco.kernel.model.Model;
import choco.kernel.model.constraints.Constraint;
import choco.kernel.model.variables.integer.IntegerVariable;
import choco.kernel.solver.Solver;

public class MyFirstChocoProgram {

    public static void main(String[] args) {

        //Constants of the problem
        int n = 3;
        int M = n*(n*n+1)/2;

        //Our model
        Model m = new CPModel();

        //Variables
        IntegerVariable[][] cells = new IntegerVariable[n][n];
        for(int i = 0; i < n; i++){
            for(int j = 0; j < n; j++){
                cells[i][j] = Choco.makeIntVar("cell"+j, 1, n*n);
                m.addVariables(cells[i][j]);
            }
        }


        //Constraints
        // ... over rows
        Constraint[] rows = new Constraint[n];
        for(int i = 0; i < n; i++){
            rows[i] = Choco.eq(Choco.sum(cells[i]), M);
        }
        m.addConstraints(rows);

        //... over columns
        // first, get the columns, with a temporary array
        IntegerVariable[][] cellsDual = new IntegerVariable[n][n];
        for(int i = 0; i < n; i++){
            for(int j = 0; j < n; j++){
                cellsDual[i][j] = cells[j][i];
            }
        }
        Constraint[] cols = new Constraint[n];
        for(int i = 0; i < n; i++){
            cols[i] = Choco.eq(Choco.sum(cellsDual[i]), M);
        }
        m.addConstraints(cols);

        //... over diagonals
        IntegerVariable[][] diags = new IntegerVariable[2][n];
        for(int i = 0; i < n; i++){
            diags[0][i] = cells[i][i];
            diags[1][i] = cells[i][(n-1)-i];
        }
        m.addConstraint(Choco.eq(Choco.sum(diags[0]), M));
        m.addConstraint(Choco.eq(Choco.sum(diags[1]), M));

        //All cells are differents from each other
        IntegerVariable[] allVars = new IntegerVariable[n*n];
        for(int i = 0; i < n; i++){
            for(int j = 0; j < n; j++){
                allVars[i*n+j] = cells[i][j];
            }
        }
        m.addConstraint(Choco.allDifferent(allVars));


        //Our solver
        Solver s = new CPSolver();

        //read the model
        s.read(m);

        //solve the problem
        s.solve();

        //Print the values
        for(int i = 0; i < n; i++){
            for(int j = 0; j < n; j++){
                System.out.print(s.getVar(cells[i][j]).getVal()+" ");
            }
            System.out.println();
        }

    }
}