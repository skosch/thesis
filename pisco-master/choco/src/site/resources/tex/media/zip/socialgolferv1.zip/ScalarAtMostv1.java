package src.samples.seminar.socialgolfer;

import src.i_want_to_use_this_old_version_of_choco.integer.constraints.AbstractLargeIntConstraint;
import src.i_want_to_use_this_old_version_of_choco.integer.IntDomainVar;
import src.i_want_to_use_this_old_version_of_choco.integer.search.RandomIntValSelector;
import src.i_want_to_use_this_old_version_of_choco.integer.search.RandomIntVarSelector;
import src.i_want_to_use_this_old_version_of_choco.mem.IStateInt;
import src.i_want_to_use_this_old_version_of_choco.mem.IStateBitSet;
import src.i_want_to_use_this_old_version_of_choco.ContradictionException;
import src.i_want_to_use_this_old_version_of_choco.AbstractProblem;
import src.i_want_to_use_this_old_version_of_choco.Problem;

/**
 * Created by IntelliJ IDEA.
 * User: charles
 * Date: 2 juin 2008
 * Time: 16:26:11
 * To change this template use File | Settings | File Templates.
 */
public class ScalarAtMostv1 extends AbstractLargeIntConstraint { 

    public IStateBitSet instPairs; // est-ce que la paire i à déjà été comptabilisé dans nbEqs
    public IStateInt nbEqs;        // nombre de paires instanciées à la même valeur 1
    public int n;
    public int k;                  // le nombre de rencontres (nombre de valeur à 1)


    // vars is the complete table of pairs
    // invariant vars.length == 2*n
    // les paires correspondent à (vars[i],vars[i + n])
    // impose le produit sigma_i (vars[i] * vars[i + n]) = k
    public ScalarAtMostv1(IntDomainVar[] vars, int n, int k) {
        super(vars);
        this.n = n;
        this.k = k;
        nbEqs = vars[0].getProblem().getEnvironment().makeInt(0);
        instPairs = vars[0].getProblem().getEnvironment().makeBitSet(n);
    }

    public boolean productNull(IntDomainVar v1, IntDomainVar v2) {
        return v1.isInstantiatedTo(0) || v2.isInstantiatedTo(0);
    }

    public boolean productOne(IntDomainVar v1, IntDomainVar v2) {
        return v1.isInstantiatedTo(1) && v2.isInstantiatedTo(1);
    }

    public void updateDataStructure(int idx) {
        if (!instPairs.get(idx) && productOne(vars[idx], vars[idx + n])) {
            instPairs.set(idx);
            nbEqs.add(1);
        }
    }

    public void awake() throws ContradictionException {
        nbEqs.set(0);
        for (int i = 0; i < n; i++) {
            updateDataStructure(i);
        }
        propagate();
    }

    public void propagateDiff(int i) throws ContradictionException {
        if (vars[i].isInstantiatedTo(1)) {
            vars[i + n].removeVal(1, cIndices[i + n]);
        } else if (vars[i + n].isInstantiatedTo(1)) {
            vars[i].removeVal(1, cIndices[i]);
        }
    }

    public void filter() throws ContradictionException {
        if (nbEqs.get() > k) // || nbDiffs.get() > n - k)
            this.fail();
        if (nbEqs.get() == k) {
            for (int i = 0; i < n; i++) {
                if (!instPairs.get(i))
                    propagateDiff(i);
            }
        }
    }


    public void propagate() throws ContradictionException {
        filter();
    }


    public void awakeOnInst(int idx) throws ContradictionException {
        //System.out.println("awake on " + vars[idx] + " to " + vars[idx].getVal());
        if (idx < n) {         // paire (idx, idx + n)
           updateDataStructure(idx);
        } else if (idx >= n) { // paire (idx - n, idx)
           updateDataStructure(idx - n);
        }
        filter();
    }

    public String toString() {
        String s = "ScalarAtMost";
        for (int i = 0; i < n; i++) {
            s += vars[i] + "*" + vars[i + n] + "+";
        }
        return s + " = " + k;
    }

    public static void main(String[] args) {
        for (int seed = 0; seed < 100; seed++) {
            AbstractProblem pb = new Problem();
            int n = 4;
            int k = 1;
            IntDomainVar[] vs1 = new IntDomainVar[2*n];
            for (int i = 0; i < 2*n; i++) {
                vs1[i] = pb.makeEnumIntVar("" + i, 0, 1);
            }
            pb.post(new ScalarAtMostv1(vs1, n, k));
            pb.getSolver().setVarSelector(new RandomIntVarSelector(pb, seed));
            pb.getSolver().setValSelector(new RandomIntValSelector(seed));
            //pb.getSolver().setValIterator(new IncreasingTrace());
            pb.solveAll();

            int nbthsol = Cnk(n, k) * (int) Math.pow(3, n - k);
            System.out.println("NbSol : " + pb.getSolver().getNbSolutions() + " The " + nbthsol);
        }
    }

    public static int Cnk(int n, int k) {
        int num = n;
        for (int i = n - 1; i > (n - k); i--) {
            num *= i;
        }
        int den = 1;
        for (int i = 2; i <= k; i++) {
            den *= i;
        }
        return num / den;
    }

    public boolean isSatisfied() {
        throw new Error("isSatisfied not yet implemented");
    }

    public void propagateEq(int i) throws ContradictionException {
         //System.out.println(this + " instantiate " + vars[i + n] + " et " + vars[i] + " a 1");
         vars[i + n].instantiate(1, cIndices[i + n]);
         vars[i].instantiate(1, cIndices[i]);
     }

}